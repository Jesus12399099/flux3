# FLUX – App estilo TikTok

Projeto Next.js + TypeScript.