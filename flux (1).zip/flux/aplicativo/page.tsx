import Feed from "./feed/Feed";
export default function Home(){
  return <main style={{background:"black",height:"100vh"}}><Feed/></main>;
}
